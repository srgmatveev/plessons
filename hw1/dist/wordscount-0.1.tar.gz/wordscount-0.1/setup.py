from setuptools import setup
setup(
    name="wordscount",
    version="0.1",
    license="BSD",
    packages=['wordscount', 'test'],
    install_requires=['nltk'],
)
